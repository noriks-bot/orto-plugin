<?php
/*
Plugin Name: Orto Bundle Selector
Description: Custom bundle radio buttons for Orto products (multiple pairs, color & size for each).
Version: 2.5
Author: Ante
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// === CONFIG ===

/**
 * Build bundle offers dynamically from ACF repeater _singlepp_orto_pairs.
 *
 * Uses:
 *  - cena_1 = regular price
 *  - cena_2 = sale price (actual price)
 *
 * Returns:
 *  per   = cena_2 / qty
 *  total = cena_2
 *  saving = (cena_1 - cena_2)
 */
 
 function gck_get_bundle_offers( $product_id = null ) : array {

    if ( ! $product_id ) {
        $product_id = get_the_ID();
    }

    if ( ! $product_id ) {
        return [];
    }

    // Get ACF repeater
    $rows = get_field('_singlepp_orto_pairs', $product_id);

    if ( empty($rows) || ! is_array($rows) ) {
        return [];
    }

    $offers = [];

    foreach ( $rows as $row ) {

        $qty = isset($row['qty']) ? (int) $row['qty'] : 0;
        if ( $qty <= 0 ) continue;

        $tekst1 = trim($row['tekst_1'] ?? '');
        $title  = trim($tekst1 . ' ');

        $regular = isset($row['cena_1']) ? floatval($row['cena_1']) : 0;
        $sale    = isset($row['cena_2']) ? floatval($row['cena_2']) : 0;

        if ( $sale <= 0 ) continue;

        // Saving text
        $saving_amount = $regular - $sale;
        $saving_text   = "Ukupna ušteda " . number_format($saving_amount, 2, '.', '') . "€";

        /**
         * SPECIAL CASE — qty = 1
         * - do NOT use floor()
         * - floating point error caused 19.99 → 19.98 (your bug)
         */
        if ( $qty === 1 ) {
            $offers[$qty] = [
                "title"  => $title,
                "per"    => number_format($sale, 2, '.', ''),  // exact sale price
                "total"  => number_format($sale, 2, '.', ''),  // exact
                "saving" => $saving_text,
            ];
            continue;
        }

        /**
         * MULTI-ITEM BUNDLE — always round DOWN (floor)
         */
        $per_item       = $sale / $qty;
        $per_item_fixed = floor($per_item * 100) / 100;

        $offers[$qty] = [
            "title"  => $title,
            "per"    => number_format($per_item_fixed, 2, '.', ''),
            "total"  => number_format($sale, 2, '.', ''),
            "saving" => $saving_text,
        ];
    }

    return $offers;
}


/**
 * Helper: is Orto bundle enabled on this product?
 * Uses ACF true/false meta _singlepp_orto_ison.
 *
 * @param int $product_id
 * @return bool
 */
function gck_is_orto_bundle_enabled( $product_id ) : bool {
    if ( ! $product_id ) {
        return false;
    }

    // ACF true/false stores '1' or '0' typically
    $flag = get_post_meta( $product_id, '_singlepp_orto_ison', true );

    // Treat any truthy value as "on"
    return ! empty( $flag );
}

/**
 * Renders the bundle selector INSIDE the add-to-cart form.
 */
add_action( 'woocommerce_before_add_to_cart_button', 'gck_render_bundle_selector', 5 );
function gck_render_bundle_selector() {
    global $product;

    // Only on product pages with Orto bundle enabled
    if ( ! is_product() || ! $product || ! gck_is_orto_bundle_enabled( $product->get_id() ) ) {
        return;
    }

    // Get offers for this specific product
    $offers = gck_get_bundle_offers( $product->get_id() );
    if ( empty( $offers ) ) {
        return;
    }

    // Get custom (non-taxonomy) attribute values from this product
    $attributes    = $product->get_attributes();
    $custom_attrs  = array();

    foreach ( $attributes as $key => $attr ) {
        if ( $attr && ! $attr->is_taxonomy() ) {
            $custom_attrs[ $key ] = $attr;
        }
    }

    // We need at least two custom attributes: first = color, second = size (by convention)
    if ( count( $custom_attrs ) < 2 ) {
        return;
    }

    $custom_keys = array_keys( $custom_attrs );

    // First custom attribute => color
    $color_key       = $custom_keys[0];
    $color_attr      = $custom_attrs[ $color_key ];
    $color_values    = $color_attr->get_options();
    $color_field_key = 'attribute_' . $color_key;

    // Second custom attribute => size
    $size_key       = $custom_keys[1];
    $size_attr      = $custom_attrs[ $size_key ];
    $size_values    = $size_attr->get_options();
    $size_field_key = 'attribute_' . $size_key;
    ?>
    <style>
    
    
      .single_add_to_cart_button {
             background: #cc0300 !important;
             border-radius: 40px !important;
        }
    
    
    
        /* Hide default quantity for products where bundle is shown */
        body.single-product .quantity {
            display: none;
        }

        .bundle-box {
            margin: 0 0 15px 0
        }
        .bundle-option {
            display: block;
            border: 2px solid #706e6e;
            background: #f4f4f4b0;
            border-radius: 8px;
            padding: 10px 15px 10px 15px;
            margin-bottom: 12px;
            cursor: pointer;
            position: relative;
            box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px,
                        rgba(60, 64, 67, 0.15) 0px 2px 6px 2px;
        }
        .bundle-option input[type="radio"] {
            margin-right: 10px;
        }
        .bundle-option-title {
            font-weight: 600;
            color: black;
            font-family: 'Barlow', sans-serif;
            font-family: 'Barlow', sans-serif;
    letter-spacing: 0.3px;
        }
        .bundle-option-sub {
            background: #971b1b;
            display: inline;
            background-color: #971b1b;
            color: white;
            font-family: 'Roboto', sans-serif;
            font-weight: 700;
            font-size: 12px;
            width: 100%;
            padding: 5px 8px 6px 8px;
            border-radius: 4px;
            clear: both;
            font-family: 'Barlow', sans-serif;
            font-family: 'Barlow', sans-serif;
    letter-spacing: 0.3px;
        }
        .bundle-option.active {
            border-color: #f39c12;
            background: #f39c1217;
        }
        .bundle-pairs {
            margin-top: 10px;
            padding-top: 10px;
            border-top: 1px dashed #f0b18a;
        }
        .bundle-pair-row {
            margin-bottom: 10px;
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            align-items: center;
        }
        .bundle-pair-row span.pair-label {
            min-width: 60px;
            font-size: 13px;
            font-weight: 600;
        }
        .bundle-pair-row select {
            padding: 6px 8px;
        }

        .bundle-pair-row small {
            color: black;
        }

        small {
            color: black;
        }

        .bundle-total-line {
            margin-top: 0px;
            text-align: right;
            font-weight: 600;
            color: black;
        }
        .bundle-total-line small {
            display: block;
            font-weight: normal;
            opacity: 0.7;
            color: black;
        }

        /* NOTE: keep elements in DOM so their fields get submitted */
        .hidden {
            visibility: hidden !important;
            height: 0 !important;
            overflow: hidden !important;
            opacity: 0 !important;
            pointer-events: none !important;
            display:none;
        }

        /* === SWATCHES === */
        .color-swatches {
            display: flex;
            gap: 4px;
            align-items: center;
        }

        .color-swatches .swatch {
            width: 35px;
            height: 34px;
            border-radius: 4px;
            border: 2px solid #ddd;
            cursor: pointer;
            display: flex;
            justify-content: center;
            align-items: center;
            transition: all .15s;
        }

        .color-swatches .swatch.active {
            border-color: #ff6d2e;
            transform: scale(1.08);
        }

        .swatch-circle {
            width: 27px;
            height: 27px;
            border-radius: 50%;
        }

        /* Automatic color styles based on slug */
        .color-black { background: #000; }
        .color-crna { background: #000; }

        .color-blue  { background: #203240; }
        .color-modra { background: #203240; }
        .color-plava { background: #203240; }

        .color-green  { background: #294d3b; }
        .color-zelena { background: #294d3b; }

        .color-gray { background: #706d78; }
        .color-siva { background: #706d78; }

        .color-crvena { background: #ba212f; }

        .color-white { background: #fff; border: 1px solid #ccc; }
        .color-bela  { background: #fff; border: 1px solid #ccc; }
        .color-bijela{ background: #fff; border: 1px solid #ccc; }
        
        
        .color-bez { background: #e4e0cf; }
        
        .color-smeda { background: #9f6f4e; }
        
        .color-zelena { background: #65633c; }
        
        .color-tamnoplava { background: #2a3262; }
        

        .whole-price-block { }

        .color-selections  { display: none; }

        /* Radio on the left */
      /* RESET NATIVE RADIO APPEARANCE */
.bundle-option input[type="radio"] {
-webkit-appearance: none;
    appearance: none;
    margin: -2px 2px 0 2px;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    border: 2px solid #ff6d2e;
    background: #fff;
    position: relative;
    cursor: pointer;
    vertical-align: middle;
    outline: none;
    box-shadow: none;
    accent-color: initial;
}

/* INNER DOT WHEN CHECKED */
.bundle-option input[type="radio"]::before {
    content: '';
    position: absolute;
    inset: 3px;
    border-radius: 50%;
    background: #ff6d2e;
    transform: scale(0);
    transition: transform 0.15s ease;
}

/* SHOW DOT ONLY WHEN CHECKED */
.bundle-option input[type="radio"]:checked::before {
    transform: scale(1);
}

/* PREVENT ANY HOVER/F FOCUS COLOR CHANGES */
.bundle-option input[type="radio"]:hover,
.bundle-option input[type="radio"]:focus,
.bundle-option input[type="radio"]:active {
    outline: none;
    box-shadow: none;
    background: #fff;
    border-color: #ff6d2e;
}



        /* Size select */
        .bundle-box .bundle-pair-row select {
            flex: 1 1 1;
            max-width: 150px;
            min-width: 77px;
            padding: 1px 10px;
            border-radius: 4px;
            border: 2px solid #ff6d2e;
            background: #ffffff;
            font-size: 18px;
            font-weight: 600;
            color: #333;
            appearance: none;
            background-image: linear-gradient(45deg, transparent 50%, #444 50%),
                              linear-gradient(135deg, #444 50%, transparent 50%);
            background-position: calc(100% - 13px) 50%, calc(100% - 8px) 50%;
            background-size: 6px 6px, 6px 6px;
            background-repeat: no-repeat;
            margin-left:-2px;
        }

        .gck-popular-badge {
              transform: rotate(3deg);
            position: absolute;
            top: -18px;
            right: -15px;
            background: #000;
            color: #fff;
            font-size: 13px;
            padding: 3px 17px;
            border-radius: 8px;
            font-weight: 600;
            z-index: 10;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            white-space: nowrap;
        }

        .gck-popular-badge-2 {
              transform: rotate(3deg);
            position: absolute;
            top: -18px;
            right: -15px;
            background: #000;
            color: #fff;
            font-size: 13px;
            padding: 3px 17px;
            border-radius: 8px;
            font-weight: 600;
            z-index: 10;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            white-space: nowrap;
        }

        /* ===== Top Divider Line ===== */
        .gck-top-banner-wrap {
            margin-bottom: 18px;
        }

        .gck-divider {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 12px;
              margin-top: 8px;
        }

        .gck-divider span {
            font-size: 15px;
            font-weight: 600;
            color: #333;
            padding: 0 12px;
        }

        .gck-divider:before,
        .gck-divider:after {
            content: "";
            flex: 1;
            height: 2px;
            background: #f39c12;
            max-width: 400px;
        }

        /* ===== Orange Timer Bar ===== */
        .gck-timer-bar {
            background: #f39c12;
            color: #fff;
            padding: 4px 14px;
            border-radius: 4px;
            text-align: center;
            font-weight: 600;
            font-size: 15px;
        }

        .gck-timer-text {
            display: inline-block;
        }

        .gck-benefits-box {
            margin: 0px 0 0px;
            font-family: inherit;
            color: #000;
            margin-top:-15px;
        }

        .gck-benefits-intro {
            font-size: 13px;
            line-height: 1.4;
            margin: 0 0 8px;
            color: #555;
        }

        .gck-benefits-list {
            list-style: none;
            margin: 0 0 8px;
            padding: 0;
            margin-top: -25px !important;
        }

        .gck-benefits-list li {
            font-size: 14px;
            line-height: 1.6;
            margin: 0 0 4px;
            display: flex;
            align-items: flex-start;
        }

        .gck-check {
            margin-right: 6px;
            font-size: 14px;
        }

        /* "Tablica veličina" link */
        .gck-size-link {
            display: inline-flex;
            align-items: center;
            font-size: 14px;
            text-decoration: underline;
            color: #000;
            margin-left: -5px;
        }

        .gck-size-icon {
            font-size: 16px;
            margin-right: 5px;
        }
        
        .shipping-sub {
            display: none !important;
        }
          
          
          
    .emoji {
           font-size: 15px !important;
        }
        
    </style>
    
     <?php if ( has_term( array( 'orto-bokserice', 'orto-bokserice2' ), 'product_cat', $product_id )     ): ?>
     
     <style>
         
          .features{
            display: none !important;
        }

     </style>
     
     <?php endif; ?>

    <div class="gck-benefits-box">
        <!--
        <p class="gck-benefits-intro">
            Majica koja rješava sve probleme.
        </p>
-->
        <ul class="gck-benefits-list">
            
            
            
              <?php if ( !has_term( array( 'orto-bokserice', 'orto-bokserice2' ), 'product_cat', $product_id )     ): ?>
            <li><span class="gck-check">✔</span> <strong>Savršeno
    pristajanje</strong></li>
    <?php endif; ?>
    
            <li><span class="gck-check">✔</span> <strong>Ultra
    mekano
    </strong></li>
            <li><span class="gck-check">✔</span> <strong>Prozračno
    i lagano</strong></li>
            <li><span class="gck-check">✔</span> <strong>Kvaliteta koja traje

    </strong></li>
        </ul>

        <a id="open-size-chartCustom" href="#size-chart" class="gck-size-link">
            <svg style="    margin-right: 5px;
    width: 23px;
    height: 23px;
    display: inline-block;
    vertical-align: middle;" xmlns="http://www.w3.org/2000/svg" width="18" height="19" viewBox="0 0 18 19" fill="none">
        <path d="M11.4124 2.58464L2.08525 11.9118C1.86558 12.1315 1.86558 12.4876 2.08525 12.7073L5.78977 16.4118C6.00944 16.6315 6.3656 16.6315 6.58527 16.4118L15.9124 7.08466C16.1321 6.86499 16.1321 6.50883 15.9124 6.28916L12.2079 2.58464C11.9883 2.36497 11.6321 2.36497 11.4124 2.58464Z" stroke="#111213" stroke-width="0.84375"></path>
        <path d="M9.28125 4.71875L11.5312 6.96875M6.75 7.25L9 9.5M4.21875 9.78125L6.46875 12.0312" stroke="#111213" stroke-width="0.84375"></path>
      </svg>
            Tablica veličina
        </a>
    </div>

    <div class="gck-top-banner-wrap">
        <div class="gck-divider">
            <span>Više komada, veća ušteda!</span>
        </div>

        <div class="gck-timer-bar">
            <span class="gck-timer-text">
                Požurite! Ponuda ističe za <span id="gck-live-timer">01:56:19</span> ⏰
            </span>
        </div>
    </div>

    <div id="bundle-selector" class="bundle-box">

        <?php
        // Second offer (by index) is default: index 0 = first, 1 = second
        $default_index = 0;
        $loop_index    = 0;

        foreach ( $offers as $pairs => $data ) :
            $is_default = ( $loop_index === $default_index );
        ?>
            <label style="position: relative; <?php if ( $loop_index == 1 ||  $loop_index == 3) : ?> margin-top: 25px;  <?php endif; ?>" class="bundle-option<?php echo $is_default ? ' active' : ''; ?>">

                <?php if ( $loop_index == 1 ) : ?>
                    <div class="gck-popular-badge">Najpopularnije 🔥</div>
                <?php endif; ?>

                <?php if ( $loop_index == 3 ) : ?>
                    <div class="gck-popular-badge-2">Najbolja cena 🔥</div>
                <?php endif; ?>

                <input type="radio"
                    required
                    name="bundle_option"
                    value="<?php echo esc_attr( $pairs ); ?>"
                    data-total="<?php echo esc_attr( $data['total'] ); ?>"
                    <?php checked( $is_default ); ?>>

                <span class="bundle-option-title">
                    <?php echo esc_html( $data['title'] ); ?> </span>—<span class="bundle-option-title"> <?php echo number_format( $data['per'], 2 ); ?>€ / kom
                </span>
                <br/>
                <!--
                <span class="bundle-option-sub">
                    <?php echo esc_html( $data['saving'] ); ?>
                </span>
                -->
                
                <div class="bundle-total-line">
                    <span style="font-weight:normal;">Ukupno:</span> <span class="line-total"><?php echo number_format( $data['total'], 2 ); ?>€</span>
                </div>

                <div class="bundle-pairs <?php echo $is_default ? '' : 'hidden'; ?>" data-pairs="<?php echo esc_attr( $pairs ); ?>">
                    <?php for ( $i = 1; $i <= $pairs; $i++ ) : ?>
                        <div class="bundle-pair-row">
                            <!-- COLOR SWATCHES (first custom attribute) -->
                            <div class="color-swatches"
                                 data-name="pairs[<?php echo $pairs; ?>][<?php echo $i; ?>][<?php echo esc_attr( $color_field_key ); ?>]">

                                <?php foreach ( $color_values as $val ) :
                                    $slug = sanitize_title( $val ); ?>
                                    <div class="swatch" data-value="<?php echo esc_attr( $val ); ?>" title="<?php echo esc_attr( $val ); ?>">
                                        <span class="swatch-circle color-<?php echo esc_attr( $slug ); ?>"></span>
                                    </div>
                                <?php endforeach; ?>

                                <!-- Hidden field WooCommerce actually uses -->
                                <input type="hidden" class="swatch-input"
                                       name="pairs[<?php echo $pairs; ?>][<?php echo $i; ?>][<?php echo esc_attr( $color_field_key ); ?>]"
                                       value="">
                            </div>

                            <!-- Size select (second custom attribute) -->
                            <select name="pairs[<?php echo $pairs; ?>][<?php echo $i; ?>][<?php echo esc_attr( $size_field_key ); ?>]">
                               
                                <?php foreach ( $size_values as $val ) : ?>
                                    <option value="<?php echo esc_attr( $val ); ?>">
                                        <?php echo esc_html( $val ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endfor; ?>
                    <small><?php esc_html_e( 'Nudimo 30 dana za povrat novca ili besplatnu zamjenu proizvoda – bezbrižna kupovina!
', 'gift-card-kompetentnost' ); ?></small>
                </div>
            </label>
        <?php
        $loop_index++;
        endforeach;
        ?>

        <!-- quantity: bundle is ONE unit in cart -->
        <input type="hidden" id="bundle_quantity" name="quantity" value="1">

    </div>
    
    
    
    <?php
    
    get_template_part( 'template_parts/size-chart-modal' );

}

/**
 * Front-end script: toggle cards, update price visually, validate selects.
 */
add_action( 'wp_footer', 'gck_bundle_js' );
function gck_bundle_js() {
    if ( ! is_product() ) return;

    global $post;
    if ( ! $post || $post->post_type !== 'product' ) {
        return;
    }

    // Only output JS on products where bundle is enabled
    if ( ! gck_is_orto_bundle_enabled( $post->ID ) ) {
        return;
    }
    ?>
<script>

document.addEventListener("DOMContentLoaded", function () {
    const modal   = document.getElementById("custom-size-chart-modal");
    const openBtn = document.getElementById("open-size-chartCustom");
    const closeX  = document.getElementById("close-size-chart-x");

    if (!modal) return;

    /* --- OPEN MODAL --- */
    openBtn?.addEventListener("click", function (e) {
        e.preventDefault();
        modal.classList.add("show");
    });

    /* --- CLOSE MODAL (X button) --- */
    closeX?.addEventListener("click", function () {
        modal.classList.remove("show");
    });

    /* --- CLOSE ON OVERLAY CLICK (optional) --- */
    modal.addEventListener("click", function (e) {
        if (e.target === modal) {
            modal.classList.remove("show");
        }
    });

    /* --- CLOSE ON ESC KEY --- */
    document.addEventListener("keydown", function (e) {
        if (e.key === "Escape") {
            modal.classList.remove("show");
        }
    });
});


document.addEventListener('DOMContentLoaded', function () {

    // 2-hour countdown
    let endTime = Date.now() + (2 * 60 * 60 * 1000);

    function updateGckTimer() {
        let now = Date.now();
        let diff = Math.max(0, endTime - now);

        let hours = String(Math.floor(diff / 3600000)).padStart(2, '0');
        let minutes = String(Math.floor((diff % 3600000) / 60000)).padStart(2, '0');
        let seconds = String(Math.floor((diff % 60000) / 1000)).padStart(2, '0');

        let el = document.getElementById("gck-live-timer");
        if (el) el.textContent = `${hours}:${minutes}:${seconds}`;
    }

    updateGckTimer();
    setInterval(updateGckTimer, 1000);

    /* === AUTO-SELECT DEFAULT COLOR + SIZE === */
    document.querySelectorAll('.bundle-pairs').forEach(wrap => {
        wrap.querySelectorAll('.bundle-pair-row').forEach(row => {

            // ----- DEFAULT COLOR -----
            const firstSwatch = row.querySelector('.color-swatches .swatch');
            const hidden      = row.querySelector('.swatch-input');

            if (firstSwatch && hidden) {
                firstSwatch.classList.add('active');
                hidden.value = firstSwatch.dataset.value;
            }

            // ----- DEFAULT SIZE -----
            const firstSize = row.querySelector('select option:nth-child(1)');
            const select    = row.querySelector('select');

            if (firstSize && select) {
                select.value = firstSize.value;
            }
        });
    });

    const selector = document.getElementById('bundle-selector');
    if (!selector) return;

    const radios   = selector.querySelectorAll('input[name="bundle_option"]');
    const qtyField = document.getElementById('bundle_quantity');

    function updateBundleUI(selectedRadio) {
        const selectedPairs = parseInt(selectedRadio.value);

        // highlight selected card
        selector.querySelectorAll('.bundle-option').forEach(function (card) {
            card.classList.remove('active');
        });
        selectedRadio.closest('.bundle-option').classList.add('active');

        // show only corresponding pairs block
        selector.querySelectorAll('.bundle-pairs').forEach(function (wrap) {
            const p = parseInt(wrap.getAttribute('data-pairs'));
            wrap.classList.toggle('hidden', p !== selectedPairs);
        });

        // quantity: bundle is always one unit in cart
        if (qtyField) {
            qtyField.value = 1;
        }

        // update visible price in Woo price element (simple visual)
        const total = selectedRadio.dataset.total;
        const priceElem = document.querySelector('.cart .summary .price .woocommerce-Price-amount');
        if (priceElem && total) {
            priceElem.innerHTML = total.replace('.', ',') + ' €';
        }
    }

    radios.forEach(function (radio) {
        radio.addEventListener('change', function () {
            updateBundleUI(this);
        });
        if (radio.checked) {
            updateBundleUI(radio);
        }
    });

    // basic client-side validation: ensure each selected pair has size & color
    const form = document.querySelector('form.cart');
    if (!form) return;

    form.addEventListener('submit', function (e) {
        const selectedRadio = selector.querySelector('input[name="bundle_option"]:checked');
        if (!selectedRadio) return;

        const pairs = parseInt(selectedRadio.value);
        const wrap  = selector.querySelector('.bundle-pairs[data-pairs="' + pairs + '"]');
        if (!wrap) return;

        let valid = true;
        // Validate size (select)
        wrap.querySelectorAll('.bundle-pair-row').forEach(function (row) {
            const selects = row.querySelectorAll('select');
            selects.forEach(function (sel) {
                if (!sel.value) {
                    valid = false;
                    sel.classList.add('woocommerce-invalid');
                } else {
                    sel.classList.remove('woocommerce-invalid');
                }
            });

            // Validate color via hidden input
            const swHidden = row.querySelector('.swatch-input');
            if (swHidden && !swHidden.value) {
                valid = false;
                swHidden.classList.add('woocommerce-invalid');
            }
        });

        if (!valid) {
            e.preventDefault();
            alert('Prosimo, izberite barvo in velikost za vsak par.');
        }
    });

    /** SWATCH LOGIC **/
    document.querySelectorAll('.color-swatches').forEach(swWrap => {
        const hidden = swWrap.querySelector('.swatch-input');

        swWrap.querySelectorAll('.swatch').forEach(swatch => {
            swatch.addEventListener('click', () => {

                // Remove active from other swatches inside same pair
                swWrap.querySelectorAll('.swatch').forEach(s => s.classList.remove('active'));

                // Mark clicked one
                swatch.classList.add('active');

                // Update hidden input value
                hidden.value = swatch.dataset.value;

                // Remove Woo invalid state
                hidden.classList.remove('woocommerce-invalid');
            });
        });
    });

});

/* === UPDATE ADD TO CART BUTTON PRICE === */
function gck_update_add_to_cart_button(total) {
    let btn = document.querySelector('.single_add_to_cart_button');
    if (!btn) return;

    // Normalize number (replace . with , for EU format)
    let formatted = total.replace('.', ',');

    // Replace ONLY the price part, keep text “Dodaj u košaricu - ”
    //btn.innerHTML = 'Dodaj u košaricu - ' + formatted + ' €';
    btn.innerHTML = 'Dodaj u košaricu'  + '';
}

document.querySelectorAll('#bundle-selector input[name="bundle_option"]').forEach(radio => {
    radio.addEventListener('change', function() {
        let total = this.dataset.total;
        gck_update_add_to_cart_button(total);
    });

    // On page load: apply default
    if (radio.checked) {
        gck_update_add_to_cart_button(radio.dataset.total);
    }
});



/* ============================================================
   AUTO-SYNC SIZES — First pair controls the remaining pairs
   ============================================================ */
document.addEventListener("DOMContentLoaded", function () {

    function activateSizeSync() {

        // Every time a bundle option changes → re-bind listeners
        document.querySelectorAll('.bundle-pairs').forEach(pairBlock => {

            // Identify first pair select
            let firstSelect = pairBlock.querySelector('.bundle-pair-row:nth-child(1) select');
            if (!firstSelect) return;

            firstSelect.addEventListener('change', function () {

                let newSize = this.value;

                // Apply to all other selects in the same bundle block
                pairBlock.querySelectorAll('.bundle-pair-row').forEach((row, index) => {
                    if (index === 0) return; // skip FIRST pair
                    let sel = row.querySelector('select');
                    if (sel) sel.value = newSize;
                });

            });

        });
    }

    // Run once on page load
    activateSizeSync();

    // Also re-run when user changes bundle option (because DOM hides/shows sections)
    document.querySelectorAll('#bundle-selector input[name="bundle_option"]').forEach(radio => {
        radio.addEventListener('change', function () {
            setTimeout(activateSizeSync, 50);
        });
    });

});




</script>
    <?php
}

/* ============================================================
 * CART / ORDER LOGIC
 * ============================================================*/

/**
 * Helper: build nice lines "Color - Size" per pair.
 *
 * @param array $pairs_data
 * @return array
 */
function gck_build_pair_lines( array $pairs_data ) : array {
    $lines = [];

    foreach ( $pairs_data as $index => $attrs ) {
        if ( ! is_array( $attrs ) ) continue;

        // We do NOT rely on specific keys; we use first and second values in the pair array.
        $values = array_values( $attrs );
        $first  = isset( $values[0] ) ? trim( (string) $values[0] ) : '';
        $second = isset( $values[1] ) ? trim( (string) $values[1] ) : '';

        if ( $first === '' && $second === '' ) {
            continue;
        }

        $line = $first;
        if ( $second !== '' ) {
            $line = $line ? $line . ' - ' . $second : $second;
        }

        if ( $line !== '' ) {
            $lines[] = $line;
        }
    }

    return $lines;
}

/**
 * When item is added to cart, attach bundle data:
 *  - number of pairs
 *  - bundle total price (single unit)
 *  - pair lines for meta ("Black - L", ...)
 */
add_filter( 'woocommerce_add_cart_item_data', 'gck_add_cart_item_data', 10, 3 );
function gck_add_cart_item_data( $cart_item_data, $product_id, $variation_id ) {

    // Only when bundle fields exist and bundle is enabled on this product
    $pairs_selected = isset( $_POST['bundle_option'] ) ? absint( $_POST['bundle_option'] ) : 0;

    if ( ! gck_is_orto_bundle_enabled( $product_id ) || ! $pairs_selected ) {
        return $cart_item_data;
    }

    // IMPORTANT: get offers for THIS product id
    $offers = gck_get_bundle_offers( $product_id );
    if ( empty( $offers ) || ! isset( $offers[ $pairs_selected ] ) ) {
        return $cart_item_data;
    }

    // Extract selected pair attributes from POST.
    $pairs_all  = isset( $_POST['pairs'] ) ? (array) $_POST['pairs'] : [];
    $pairs_data = isset( $pairs_all[ $pairs_selected ] ) ? (array) $pairs_all[ $pairs_selected ] : [];

    // Meta lines like "Black - L"
    $lines = gck_build_pair_lines( $pairs_data );

    // Pricing: bundle is ONE product, price = bundle total
    $total      = (float) $offers[ $pairs_selected ]['total']; // bundle total
    $unit_price = $total;

    // Attach pricing & meta to cart item
    $cart_item_data['_orto_bundle_pairs']      = $pairs_selected;
    $cart_item_data['_orto_bundle_total']      = $total;
    $cart_item_data['_orto_bundle_unit_price'] = $unit_price;
    $cart_item_data['_orto_pairs_json']        = wp_json_encode( $pairs_data );
    $cart_item_data['_orto_lines']             = $lines;

    // Prevent Woo from merging bundles with different selections
    $cart_item_data['orto_unique_key'] = md5( microtime( true ) . wp_rand() . serialize( $cart_item_data ) );

    return $cart_item_data;
}

/**
 * Central helper: actually apply our custom unit price to a cart item.
 *
 * @param array $cart_item
 * @return array
 */
function gck_apply_price_to_cart_item( $cart_item ) {
    if ( isset( $cart_item['_orto_bundle_unit_price'] ) && $cart_item['data'] instanceof WC_Product ) {
        $price = (float) $cart_item['_orto_bundle_unit_price'];
        if ( $price > 0 ) {
            $cart_item['data']->set_price( $price );
        }
    }
    return $cart_item;
}

/**
 * Apply price when item is first added to cart.
 */
add_filter( 'woocommerce_add_cart_item', 'gck_add_cart_item_apply_price', 20, 2 );
function gck_add_cart_item_apply_price( $cart_item, $cart_item_key ) {
    return gck_apply_price_to_cart_item( $cart_item );
}

/**
 * Apply price when cart is loaded from session (page reload, etc.).
 */
add_filter( 'woocommerce_get_cart_item_from_session', 'gck_session_cart_item_apply_price', 20, 2 );
function gck_session_cart_item_apply_price( $cart_item, $values ) {
    if ( isset( $values['_orto_bundle_unit_price'] ) ) {
        $cart_item['_orto_bundle_unit_price'] = $values['_orto_bundle_unit_price'];
    }
    if ( isset( $values['_orto_lines'] ) ) {
        $cart_item['_orto_lines'] = $values['_orto_lines'];
    }
    return gck_apply_price_to_cart_item( $cart_item );
}

/**
 * Extra safety: before totals are calculated, make sure price is correct.
 */
add_action( 'woocommerce_before_calculate_totals', 'gck_adjust_bundle_price', 9999 );
function gck_adjust_bundle_price( $cart ) {
    if ( ! $cart instanceof WC_Cart ) {
        return;
    }

    foreach ( $cart->get_cart() as $key => &$item ) {
        $item = gck_apply_price_to_cart_item( $item );
    }
}

/**
 * Show bundle contents in cart / checkout under the line item.
 */
add_filter( 'woocommerce_get_item_data', 'gck_display_item_data', 10, 2 );
function gck_display_item_data( $item_data, $cart_item ) {

    if ( empty( $cart_item['_orto_lines'] ) || ! is_array( $cart_item['_orto_lines'] ) ) {
        return $item_data;
    }

    $lines     = array_values( $cart_item['_orto_lines'] );
    $numbered  = [];
    foreach ( $lines as $i => $line ) {
        $numbered[] = ( $i + 1 ) . ': ' . $line;
    }

    $value = implode( '<br>', array_map( 'esc_html', $numbered ) );

    // name=false -> Woo prints only the value (no dt label)
    $item_data[] = array(
        'name'    => false,
        'display' => $value,
    );

    return $item_data;
}

/**
 * Save each pair as a numbered meta line in the order item:
 * meta key "1" => "Black - L", "2" => "White - M", ...
 */
add_action( 'woocommerce_checkout_create_order_line_item', 'gck_order_item_meta', 10, 4 );
function gck_order_item_meta( $item, $cart_item_key, $values, $order ) {

    if ( empty( $values['_orto_lines'] ) || ! is_array( $values['_orto_lines'] ) ) {
        return;
    }

    $lines = array_values( $values['_orto_lines'] );
    foreach ( $lines as $i => $line ) {
        $item->add_meta_data( (string) ( $i + 1 ), sanitize_text_field( $line ), true );
    }

    if ( ! empty( $values['_orto_bundle_pairs'] ) ) {
        $item->add_meta_data( '_bundle_pairs', (int) $values['_orto_bundle_pairs'], true );
    }
}
